print("This is a script from a utf8 file")
print("tolua: 你好! こんにちは! 안녕하세요!")
